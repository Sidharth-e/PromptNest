"use strict";
(() => {
  // src/services/PromptManager.ts
  var _PromptManager = class _PromptManager {
    // Create a new prompt
    async createPrompt(keyword, content) {
      const prompt = {
        id: this.generateId(),
        keyword: keyword.trim(),
        content: content.trim(),
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      };
      const prompts = await this.getAllPrompts();
      prompts.push(prompt);
      await this.savePrompts(prompts);
      return prompt;
    }
    // Get all prompts
    async getAllPrompts() {
      return new Promise((resolve) => {
        chrome.storage.local.get([_PromptManager.STORAGE_KEY], (result) => {
          const prompts = result[_PromptManager.STORAGE_KEY] || [];
          const parsedPrompts = prompts.map((p) => ({
            ...p,
            createdAt: new Date(p.createdAt),
            updatedAt: new Date(p.updatedAt)
          }));
          resolve(parsedPrompts);
        });
      });
    }
    // Get prompt by keyword
    async getPromptByKeyword(keyword) {
      const prompts = await this.getAllPrompts();
      return prompts.find((p) => p.keyword === keyword.trim()) || null;
    }
    // Update an existing prompt
    async updatePrompt(id, keyword, content) {
      const prompts = await this.getAllPrompts();
      const index = prompts.findIndex((p) => p.id === id);
      if (index === -1) {
        return null;
      }
      const prompt = prompts[index];
      if (keyword !== void 0) prompt.keyword = keyword.trim();
      if (content !== void 0) prompt.content = content.trim();
      prompt.updatedAt = /* @__PURE__ */ new Date();
      await this.savePrompts(prompts);
      return prompt;
    }
    // Delete a prompt
    async deletePrompt(id) {
      const prompts = await this.getAllPrompts();
      const filteredPrompts = prompts.filter((p) => p.id !== id);
      if (filteredPrompts.length === prompts.length) {
        return false;
      }
      await this.savePrompts(filteredPrompts);
      return true;
    }
    // Delete prompt by keyword
    async deletePromptByKeyword(keyword) {
      const prompts = await this.getAllPrompts();
      const filteredPrompts = prompts.filter((p) => p.keyword !== keyword.trim());
      if (filteredPrompts.length === prompts.length) {
        return false;
      }
      await this.savePrompts(filteredPrompts);
      return true;
    }
    // Save prompts to storage
    async savePrompts(prompts) {
      return new Promise((resolve) => {
        chrome.storage.local.set({ [_PromptManager.STORAGE_KEY]: prompts }, () => {
          resolve();
        });
      });
    }
    // Generate unique ID
    generateId() {
      return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
    // Clear all prompts
    async clearAllPrompts() {
      return new Promise((resolve) => {
        chrome.storage.local.remove([_PromptManager.STORAGE_KEY], () => {
          resolve();
        });
      });
    }
  };
  _PromptManager.STORAGE_KEY = "promptNest_prompts";
  var PromptManager = _PromptManager;

  // src/Ui/CustomAlert.ts
  var CustomAlert = class {
    static ensureStyles() {
      if (this.stylesInjected) return;
      this.stylesInjected = true;
      const style = document.createElement("style");
      style.id = "pn-custom-alert-styles";
      style.innerHTML = `
		  :root {
		    --pn-primary: #4a90e2;
		    --pn-success: #4caf50;
		    --pn-danger: #f44336;
		    --pn-warning: #ff9800;
		    --pn-surface: #ffffff;
		    --pn-text: #333333;
		    --pn-border: #e0e6ed;
		    --pn-shadow: 0 6px 25px rgba(0, 0, 0, 0.1);
		    --pn-font: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
		  }

		  .pn-alert-backdrop {
		    position: fixed;
		    inset: 0;
		    background: rgba(0,0,0,0.35);
		    display: flex;
		    align-items: center;
		    justify-content: center;
		    z-index: 10002;
		    opacity: 0;
		    visibility: hidden;
		    transition: opacity 0.2s ease, visibility 0.2s ease;
			font-family: var(--pn-font);
		  }
		  .pn-alert-backdrop.pn-open { opacity: 1; visibility: visible; }

		  .pn-alert {
		    background: var(--pn-surface);
		    border: 1px solid var(--pn-border);
		    border-left: 6px solid var(--pn-primary);
		    border-radius: 10px;
		    width: calc(min(92vw, 440px));
		    box-shadow: var(--pn-shadow);
		    transform: translateY(12px);
		    opacity: 0;
		    transition: transform 0.2s ease, opacity 0.2s ease;
		  }
		  .pn-alert-backdrop.pn-open .pn-alert { transform: translateY(0); opacity: 1; }

		  .pn-alert-header { display:flex; justify-content: space-between; align-items:center; padding: 14px 16px 0 16px; }
		  .pn-alert-title { margin: 0; font-size: 16px; font-weight: 700; color: var(--pn-text); }
		  .pn-alert-close { background:none; border:none; font-size: 22px; line-height: 1; cursor:pointer; color:#777; width:28px; height:28px; border-radius: 6px; }
		  .pn-alert-close:hover { background:#f2f4f8; color:#333; }

		  .pn-alert-body { padding: 10px 16px 16px 16px; color: var(--pn-text); font-size: 14px; line-height: 1.5; }
		  .pn-alert-actions { display:flex; gap:10px; justify-content:flex-end; padding: 0 16px 16px 16px; }
		  .pn-alert-button { border:none; padding: 8px 14px; border-radius: 6px; font-size: 14px; cursor:pointer; }
		  .pn-alert-button-primary { background: var(--pn-primary); color: #fff; }
		  .pn-alert-button-primary:hover { filter: brightness(0.95); }
		  .pn-alert-button-secondary { background: #eef2f7; color: #333; }
		  .pn-alert-button-secondary:hover { filter: brightness(0.98); }

		  /* Types */
		  .pn-alert.type-success { border-left-color: var(--pn-success); }
		  .pn-alert.type-warning { border-left-color: var(--pn-warning); }
		  .pn-alert.type-error { border-left-color: var(--pn-danger); }
		`;
      document.head.appendChild(style);
    }
    static show(message, options = {}) {
      this.ensureStyles();
      const { title = "Notice", type = "info", autoCloseMs } = options;
      return new Promise((resolve) => {
        const backdrop = document.createElement("div");
        backdrop.className = "pn-alert-backdrop";
        const alertBox = document.createElement("div");
        alertBox.className = `pn-alert type-${type}`;
        alertBox.innerHTML = `
			  <div class="pn-alert-header">
			    <h3 class="pn-alert-title">${title}</h3>
			    <button class="pn-alert-close" aria-label="Close">&times;</button>
			  </div>
			  <div class="pn-alert-body">${message}</div>
			  <div class="pn-alert-actions">
			    <button class="pn-alert-button pn-alert-button-secondary" data-action="dismiss">Dismiss</button>
			    <button class="pn-alert-button pn-alert-button-primary" data-action="ok">OK</button>
			  </div>
			`;
        const cleanup = () => {
          backdrop.classList.remove("pn-open");
          setTimeout(() => backdrop.remove(), 180);
        };
        const complete = () => {
          cleanup();
          resolve();
        };
        backdrop.addEventListener("click", (e) => {
          if (e.target === backdrop) complete();
        });
        alertBox.querySelector(".pn-alert-close")?.addEventListener("click", complete);
        alertBox.querySelector('[data-action="dismiss"]')?.addEventListener("click", complete);
        alertBox.querySelector('[data-action="ok"]')?.addEventListener("click", complete);
        backdrop.appendChild(alertBox);
        document.body.appendChild(backdrop);
        requestAnimationFrame(() => backdrop.classList.add("pn-open"));
        if (typeof autoCloseMs === "number" && autoCloseMs > 0) {
          setTimeout(() => complete(), autoCloseMs);
        }
      });
    }
  };
  CustomAlert.stylesInjected = false;
  var CustomAlert_default = CustomAlert;

  // src/Ui/promptUi.ts
  var PromptUI = class {
    constructor() {
      this.prompts = [];
      this.isVisible = false;
      this.promptManager = new PromptManager();
      this.injectStyles();
      this.container = this.createContainer();
      this.loadPrompts();
    }
    // Injects a single, modern stylesheet into the document's head
    injectStyles() {
      const styleId = "prompt-nest-styles";
      if (document.getElementById(styleId)) return;
      const style = document.createElement("style");
      style.id = styleId;
      style.innerHTML = `
      :root {
        --pn-primary: #4a90e2;
        --pn-primary-dark: #357ABD;
        --pn-background: #f7f9fc;
        --pn-surface: #ffffff;
        --pn-text: #333333;
        --pn-text-secondary: #666666;
        --pn-border: #e0e6ed;
        --pn-success: #4caf50;
        --pn-danger: #f44336;
        --pn-shadow: 0 6px 25px rgba(0, 0, 0, 0.1);
        --pn-font: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      }
      
      #prompt-nest-extension * {
          box-sizing: border-box;
      }

      /* Main Modal Backdrop */
      #prompt-nest-extension {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.4);
        z-index: 9999;
        display: flex;
        align-items: center; 
        justify-content: center;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.4s ease-in-out, visibility 0.4s ease-in-out;
        font-family: var(--pn-font);
      }

      #prompt-nest-extension.pn-open {
        opacity: 1;
        visibility: visible;
      }

      /* Main Modal Content Box */
      .pn-main-modal {
        background: var(--pn-background);
        border-radius: 12px;
        box-shadow: var(--pn-shadow);
        width: 90%;
        max-width: 800px;
        max-height: 70vh;
        display: flex;
        flex-direction: column;
        color: var(--pn-text);
        overflow: hidden;
        opacity: 0;
        transform: translateX(100vw);
        transition: transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1), opacity 0.3s ease-out;
      }

      #prompt-nest-extension.pn-open .pn-main-modal {
        opacity: 1;
        transform: translateX(0);
      }

      /* Header */
      .pn-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 24px;
        border-bottom: 1px solid var(--pn-border);
        background: var(--pn-surface);
        flex-shrink: 0;
      }
      .pn-title { margin: 0; color: var(--pn-primary); font-size: 20px; font-weight: 600; }
      .pn-header-actions { display: flex; align-items: center; gap: 8px; }
      .pn-close-button {
        background: none; border: none; font-size: 28px; cursor: pointer; color: var(--pn-text-secondary);
        width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;
        border-radius: 50%; transition: background-color 0.2s, color 0.2s; line-height: 1;
      }
      .pn-close-button:hover { background-color: #eef2f7; color: var(--pn-text); }

      /* Form Container (Collapsible) - UI FIX ADDED */
      .pn-form-container {
        background: var(--pn-surface);
        border-bottom: 1px solid var(--pn-border);
        padding: 0 24px;
        margin: 0;
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease-in-out, padding 0.3s ease-in-out;
        flex-shrink: 0; /* Prevents the form from being squished by the list */
      }
      .pn-form-container.active { padding: 20px 24px; max-height: 500px; }
      .pn-form h3 { margin: 0 0 15px 0; font-size: 16px; font-weight: 600; color: var(--pn-text); }
      .pn-form label { display: block; margin-bottom: 6px; font-size: 13px; color: var(--pn-text-secondary); font-weight: 500; }
      .pn-input, .pn-textarea {
        width: 100%; padding: 10px; border: 1px solid var(--pn-border);
        border-radius: 6px; font-size: 14px; margin-bottom: 12px;
        transition: border-color 0.2s, box-shadow 0.2s;
        font-family: var(--pn-font); color: var(--pn-text);
      }
      .pn-input:focus, .pn-textarea:focus { outline: none; border-color: var(--pn-primary); box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2); }
      .pn-textarea { min-height: 80px; resize: vertical; }

      /* Buttons */
      .pn-button {
        border: none; padding: 10px 16px; border-radius: 6px; font-size: 14px; font-weight: 500;
        cursor: pointer; transition: background-color 0.2s, transform 0.1s;
      }
      .pn-button:active { transform: translateY(1px); }
      .pn-button-primary { background: var(--pn-primary); color: white; }
      .pn-button-primary:hover { background: var(--pn-primary-dark); }
      .pn-button-secondary { background: #eef2f7; color: var(--pn-text); }
      .pn-button-secondary:hover { background: #e0e6ed; }

      /* Prompts List */
      #prompts-list { flex-grow: 1; overflow-y: auto; padding: 12px 24px; }
      #prompts-list::-webkit-scrollbar { width: 6px; }
      #prompts-list::-webkit-scrollbar-thumb { background: #ccc; border-radius: 3px; }
      #prompts-list::-webkit-scrollbar-thumb:hover { background: #aaa; }
      
      .pn-empty-message { text-align: center; color: var(--pn-text-secondary); font-size: 14px; margin-top: 40px; font-style: italic; }
      
      .pn-prompt-item {
        border: 1px solid transparent; border-bottom: 1px solid var(--pn-border);
        padding: 15px 10px; margin-bottom: 4px; background: transparent;
        display: flex; flex-direction: column; gap: 8px; border-radius: 8px;
        transition: background-color 0.2s, border-color 0.2s;
      }
      .pn-prompt-item:hover { background-color: var(--pn-surface); border-color: var(--pn-border); }
      .pn-prompt-header { display: flex; justify-content: space-between; align-items: flex-start; }
      .pn-prompt-keyword {
        font-weight: 600; color: var(--pn-primary); font-size: 14px;
        background-color: #eef2f7; padding: 4px 8px; border-radius: 4px;
        align-self: flex-start;
      }
      .pn-prompt-content { color: var(--pn-text); font-size: 14px; line-height: 1.5; word-wrap: break-word; padding-left: 2px; }
      .pn-prompt-actions { display: flex; gap: 10px; align-items: center; opacity: 0; transition: opacity 0.2s ease-in-out; }
      .pn-prompt-item:hover .pn-prompt-actions { opacity: 1; }
      .pn-icon-button {
        background: none; border: none; padding: 4px; cursor: pointer; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        width: 28px; height: 28px; transition: background-color 0.2s;
      }
      .pn-icon-button:hover { background-color: #e0e6ed; }
      .pn-icon-button svg { width: 18px; height: 18px; }
      .pn-icon-button.edit svg { fill: var(--pn-success); }
      .pn-icon-button.delete svg { fill: var(--pn-danger); }

      /* Edit Modal (sits on top of the main modal) */
      .pn-modal-backdrop {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.4); z-index: 10001;
        display: flex; align-items: center; justify-content: center;
        opacity: 0; visibility: hidden;
        transition: opacity 0.2s, visibility 0.2s;
      }
      .pn-modal-backdrop.active { opacity: 1; visibility: visible; }
      .pn-modal-content {
        background: var(--pn-surface); padding: 24px; border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1); width: 90%; max-width: 420px;
        transform: scale(0.95); transition: transform 0.2s;
      }
      .pn-modal-backdrop.active .pn-modal-content { transform: scale(1); }
      .pn-modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
      .pn-modal-header h3 { margin: 0; font-size: 18px; color: var(--pn-text); }
      .pn-modal-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 16px; }
    `;
      document.head.appendChild(style);
    }
    createContainer() {
      const backdrop = document.createElement("div");
      backdrop.id = "prompt-nest-extension";
      const modalContent = document.createElement("div");
      modalContent.className = "pn-main-modal";
      this.createHeader(modalContent);
      this.createAddPromptForm(modalContent);
      this.createPromptsList(modalContent);
      this.createEditModal(backdrop);
      backdrop.appendChild(modalContent);
      backdrop.addEventListener("click", (e) => {
        if (e.target === backdrop) {
          this.hide();
        }
      });
      return backdrop;
    }
    createHeader(container) {
      const header = document.createElement("div");
      header.className = "pn-header";
      const title = document.createElement("h2");
      title.textContent = "PromptNest";
      title.className = "pn-title";
      const headerActions = document.createElement("div");
      headerActions.className = "pn-header-actions";
      const newPromptButton = document.createElement("button");
      newPromptButton.textContent = "New Prompt";
      newPromptButton.className = "pn-button pn-button-primary";
      newPromptButton.addEventListener("click", () => {
        this.container.querySelector(".pn-form-container")?.classList.toggle("active");
      });
      const closeButton = document.createElement("button");
      closeButton.innerHTML = "&times;";
      closeButton.className = "pn-close-button";
      closeButton.title = "Close";
      closeButton.addEventListener("click", () => this.hide());
      headerActions.appendChild(newPromptButton);
      headerActions.appendChild(closeButton);
      header.appendChild(title);
      header.appendChild(headerActions);
      container.appendChild(header);
    }
    createAddPromptForm(container) {
      const formContainer = document.createElement("div");
      formContainer.className = "pn-form-container";
      const form = document.createElement("form");
      form.className = "pn-form";
      form.id = "pn-add-form";
      form.innerHTML = `
        <h3>Add New Prompt</h3>
        <label>Keyword (e.g., ::email)</label>
        <input type="text" placeholder="::email-summary" class="pn-input" name="keyword">
        <label>Prompt Content</label>
        <textarea placeholder="Summarize the following email thread..." class="pn-textarea" name="content"></textarea>
        <button type="submit" class="pn-button pn-button-primary">Add Prompt</button>
    `;
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const keywordInput = form.querySelector('input[name="keyword"]');
        const contentInput = form.querySelector('textarea[name="content"]');
        const keyword = keywordInput?.value.trim() ?? "";
        const content = contentInput?.value.trim() ?? "";
        const isDuplicate = this.prompts.some((p) => p.keyword.toLowerCase() === keyword.toLowerCase());
        if (isDuplicate) {
          CustomAlert_default.show(`The keyword "${keyword}" already exists. Please choose a unique keyword.`, { title: "Duplicate Keyword", type: "warning", autoCloseMs: 3500 });
          return;
        }
        if (!keyword || !content) {
          CustomAlert_default.show("Please fill in both keyword and content.", { title: "Missing Fields", type: "warning", autoCloseMs: 3e3 });
          return;
        }
        if (!keyword.startsWith("::")) {
          CustomAlert_default.show("Keyword must start with ::", { title: "Invalid Keyword", type: "info", autoCloseMs: 3e3 });
          return;
        }
        try {
          await this.promptManager.createPrompt(keyword, content);
          if (keywordInput) keywordInput.value = "";
          if (contentInput) contentInput.value = "";
          formContainer.classList.remove("active");
          await this.loadPrompts();
        } catch (error) {
          CustomAlert_default.show("Error adding prompt: " + error, { title: "Add Failed", type: "error" });
        }
      });
      formContainer.appendChild(form);
      container.appendChild(formContainer);
    }
    createPromptsList(container) {
      const listContainer = document.createElement("div");
      listContainer.id = "prompts-list";
      container.appendChild(listContainer);
    }
    async loadPrompts() {
      this.prompts = await this.promptManager.getAllPrompts();
      this.renderPrompts();
    }
    renderPrompts() {
      const listContainer = this.container.querySelector("#prompts-list");
      if (!listContainer) return;
      listContainer.innerHTML = "";
      if (this.prompts.length === 0) {
        listContainer.innerHTML = `<p class="pn-empty-message">No prompts saved. Add one to get started! \u2728</p>`;
        return;
      }
      this.prompts.forEach((prompt) => {
        const promptItem = this.createPromptItem(prompt);
        listContainer.appendChild(promptItem);
      });
    }
    createPromptItem(prompt) {
      const item = document.createElement("div");
      item.className = "pn-prompt-item";
      item.innerHTML = `
        <div class="pn-prompt-header">
            <div class="pn-prompt-keyword">${prompt.keyword}</div>
            <div class="pn-prompt-actions">
                <button class="pn-icon-button edit" title="Edit Prompt">
                    <svg viewBox="0 0 24 24"><path d="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.13,5.12L18.88,8.87M3,17.25V21H6.75L17.81,9.94L14.06,6.19L3,17.25Z" /></svg>
                </button>
                <button class="pn-icon-button delete" title="Delete Prompt">
                    <svg viewBox="0 0 24 24"><path d="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z" /></svg>
                </button>
            </div>
        </div>
        <div class="pn-prompt-content">${prompt.content}</div>
    `;
      item.querySelector(".edit")?.addEventListener("click", () => {
        this.showEditModal(prompt);
      });
      item.querySelector(".delete")?.addEventListener("click", async () => {
        if (confirm("Are you sure you want to delete this prompt?")) {
          try {
            await this.promptManager.deletePrompt(prompt.id);
            await this.loadPrompts();
          } catch (error) {
            CustomAlert_default.show("Error deleting prompt: " + error, { title: "Delete Failed", type: "error" });
          }
        }
      });
      return item;
    }
    createEditModal(container) {
      const modalBackdrop = document.createElement("div");
      modalBackdrop.className = "pn-modal-backdrop";
      modalBackdrop.id = "pn-edit-modal";
      modalBackdrop.innerHTML = `
        <div class="pn-modal-content">
            <div class="pn-modal-header">
                <h3>Edit Prompt</h3>
                <button class="pn-close-button">&times;</button>
            </div>
            <form id="pn-edit-form">
                <label>Keyword</label>
                <input type="text" class="pn-input" name="keyword">
                <label>Content</label>
                <textarea class="pn-textarea" name="content"></textarea>
                <div class="pn-modal-actions">
                    <button type="button" class="pn-button pn-button-secondary" id="pn-edit-cancel">Cancel</button>
                    <button type="submit" class="pn-button pn-button-primary" id="pn-edit-save">Save Changes</button>
                </div>
            </form>
        </div>
      `;
      const closeModal = () => modalBackdrop.classList.remove("active");
      modalBackdrop.querySelector(".pn-close-button")?.addEventListener("click", closeModal);
      modalBackdrop.querySelector("#pn-edit-cancel")?.addEventListener("click", closeModal);
      modalBackdrop.addEventListener("click", (e) => {
        if (e.target === modalBackdrop) {
          closeModal();
        }
      });
      container.appendChild(modalBackdrop);
    }
    showEditModal(prompt) {
      const modal = this.container.querySelector("#pn-edit-modal");
      const form = modal?.querySelector("#pn-edit-form");
      if (!modal || !form) return;
      const keywordInput = form.querySelector('input[name="keyword"]');
      const contentInput = form.querySelector('textarea[name="content"]');
      if (keywordInput) keywordInput.value = prompt.keyword;
      if (contentInput) contentInput.value = prompt.content;
      const handleSubmit = async (e) => {
        e.preventDefault();
        const newKeyword = keywordInput?.value.trim() ?? "";
        const newContent = contentInput?.value.trim() ?? "";
        if (!newKeyword || !newContent) {
          CustomAlert_default.show("Please provide both keyword and content.", { title: "Missing Fields", type: "warning", autoCloseMs: 3e3 });
          return;
        }
        try {
          await this.promptManager.updatePrompt(prompt.id, newKeyword, newContent);
          modal.classList.remove("active");
          await this.loadPrompts();
        } catch (error) {
          CustomAlert_default.show("Error updating prompt: " + error, { title: "Update Failed", type: "error" });
        }
      };
      form.removeEventListener("submit", form.__handleSubmit__);
      form.addEventListener("submit", handleSubmit);
      form.__handleSubmit__ = handleSubmit;
      modal.classList.add("active");
    }
    // --- Public Methods ---
    show() {
      if (!this.isVisible) {
        document.body.appendChild(this.container);
        setTimeout(() => this.container.classList.add("pn-open"), 10);
        this.isVisible = true;
        this.loadPrompts();
      }
    }
    hide() {
      if (this.isVisible) {
        this.container.classList.remove("pn-open");
        this.isVisible = false;
      }
    }
    toggle() {
      this.isVisible ? this.hide() : this.show();
    }
    getIsVisible() {
      return this.isVisible;
    }
  };
})();
