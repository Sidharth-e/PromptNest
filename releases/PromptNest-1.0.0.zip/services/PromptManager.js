"use strict";
(() => {
  // src/services/PromptManager.ts
  var _PromptManager = class _PromptManager {
    // Create a new prompt
    async createPrompt(keyword, content) {
      const prompt = {
        id: this.generateId(),
        keyword: keyword.trim(),
        content: content.trim(),
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      };
      const prompts = await this.getAllPrompts();
      prompts.push(prompt);
      await this.savePrompts(prompts);
      return prompt;
    }
    // Get all prompts
    async getAllPrompts() {
      return new Promise((resolve) => {
        chrome.storage.local.get([_PromptManager.STORAGE_KEY], (result) => {
          const prompts = result[_PromptManager.STORAGE_KEY] || [];
          const parsedPrompts = prompts.map((p) => ({
            ...p,
            createdAt: new Date(p.createdAt),
            updatedAt: new Date(p.updatedAt)
          }));
          resolve(parsedPrompts);
        });
      });
    }
    // Get prompt by keyword
    async getPromptByKeyword(keyword) {
      const prompts = await this.getAllPrompts();
      return prompts.find((p) => p.keyword === keyword.trim()) || null;
    }
    // Update an existing prompt
    async updatePrompt(id, keyword, content) {
      const prompts = await this.getAllPrompts();
      const index = prompts.findIndex((p) => p.id === id);
      if (index === -1) {
        return null;
      }
      const prompt = prompts[index];
      if (keyword !== void 0) prompt.keyword = keyword.trim();
      if (content !== void 0) prompt.content = content.trim();
      prompt.updatedAt = /* @__PURE__ */ new Date();
      await this.savePrompts(prompts);
      return prompt;
    }
    // Delete a prompt
    async deletePrompt(id) {
      const prompts = await this.getAllPrompts();
      const filteredPrompts = prompts.filter((p) => p.id !== id);
      if (filteredPrompts.length === prompts.length) {
        return false;
      }
      await this.savePrompts(filteredPrompts);
      return true;
    }
    // Delete prompt by keyword
    async deletePromptByKeyword(keyword) {
      const prompts = await this.getAllPrompts();
      const filteredPrompts = prompts.filter((p) => p.keyword !== keyword.trim());
      if (filteredPrompts.length === prompts.length) {
        return false;
      }
      await this.savePrompts(filteredPrompts);
      return true;
    }
    // Save prompts to storage
    async savePrompts(prompts) {
      return new Promise((resolve) => {
        chrome.storage.local.set({ [_PromptManager.STORAGE_KEY]: prompts }, () => {
          resolve();
        });
      });
    }
    // Generate unique ID
    generateId() {
      return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
    // Clear all prompts
    async clearAllPrompts() {
      return new Promise((resolve) => {
        chrome.storage.local.remove([_PromptManager.STORAGE_KEY], () => {
          resolve();
        });
      });
    }
  };
  _PromptManager.STORAGE_KEY = "promptNest_prompts";
  var PromptManager = _PromptManager;
})();
