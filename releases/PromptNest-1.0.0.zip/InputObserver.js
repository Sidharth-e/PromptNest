"use strict";
(() => {
  // src/PromptManager.ts
  var _PromptManager = class _PromptManager {
    // Create a new prompt
    async createPrompt(keyword, content) {
      const prompt = {
        id: this.generateId(),
        keyword: keyword.trim(),
        content: content.trim(),
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      };
      const prompts = await this.getAllPrompts();
      prompts.push(prompt);
      await this.savePrompts(prompts);
      return prompt;
    }
    // Get all prompts
    async getAllPrompts() {
      return new Promise((resolve) => {
        chrome.storage.local.get([_PromptManager.STORAGE_KEY], (result) => {
          const prompts = result[_PromptManager.STORAGE_KEY] || [];
          const parsedPrompts = prompts.map((p) => ({
            ...p,
            createdAt: new Date(p.createdAt),
            updatedAt: new Date(p.updatedAt)
          }));
          resolve(parsedPrompts);
        });
      });
    }
    // Get prompt by keyword
    async getPromptByKeyword(keyword) {
      const prompts = await this.getAllPrompts();
      return prompts.find((p) => p.keyword === keyword.trim()) || null;
    }
    // Update an existing prompt
    async updatePrompt(id, keyword, content) {
      const prompts = await this.getAllPrompts();
      const index = prompts.findIndex((p) => p.id === id);
      if (index === -1) {
        return null;
      }
      const prompt = prompts[index];
      if (keyword !== void 0) prompt.keyword = keyword.trim();
      if (content !== void 0) prompt.content = content.trim();
      prompt.updatedAt = /* @__PURE__ */ new Date();
      await this.savePrompts(prompts);
      return prompt;
    }
    // Delete a prompt
    async deletePrompt(id) {
      const prompts = await this.getAllPrompts();
      const filteredPrompts = prompts.filter((p) => p.id !== id);
      if (filteredPrompts.length === prompts.length) {
        return false;
      }
      await this.savePrompts(filteredPrompts);
      return true;
    }
    // Delete prompt by keyword
    async deletePromptByKeyword(keyword) {
      const prompts = await this.getAllPrompts();
      const filteredPrompts = prompts.filter((p) => p.keyword !== keyword.trim());
      if (filteredPrompts.length === prompts.length) {
        return false;
      }
      await this.savePrompts(filteredPrompts);
      return true;
    }
    // Save prompts to storage
    async savePrompts(prompts) {
      return new Promise((resolve) => {
        chrome.storage.local.set({ [_PromptManager.STORAGE_KEY]: prompts }, () => {
          resolve();
        });
      });
    }
    // Generate unique ID
    generateId() {
      return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
    // Clear all prompts
    async clearAllPrompts() {
      return new Promise((resolve) => {
        chrome.storage.local.remove([_PromptManager.STORAGE_KEY], () => {
          resolve();
        });
      });
    }
  };
  _PromptManager.STORAGE_KEY = "promptNest_prompts";
  var PromptManager = _PromptManager;

  // src/InputObserver.ts
  var InputObserver = class {
    constructor() {
      this.observer = null;
      this.inputListeners = /* @__PURE__ */ new Map();
      this.contentEditableListeners = /* @__PURE__ */ new Map();
      this.promptManager = new PromptManager();
      this.startObserving();
    }
    startObserving() {
      this.observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              const element = node;
              this.attachListenersToElement(element);
              const textareas = element.querySelectorAll("textarea");
              textareas.forEach((input) => this.attachListenersToElement(input));
              const contentEditables = element.querySelectorAll('[contenteditable="true"]');
              contentEditables.forEach((editable) => this.attachListenersToElement(editable));
            }
          });
        });
      });
      this.observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      this.attachListenersToExistingElements();
    }
    attachListenersToExistingElements() {
      const textareas = document.querySelectorAll("textarea");
      textareas.forEach((input) => this.attachListenersToElement(input));
      const contentEditables = document.querySelectorAll('[contenteditable="true"]');
      contentEditables.forEach((editable) => this.attachListenersToElement(editable));
    }
    attachListenersToElement(element) {
      if (element instanceof HTMLTextAreaElement) {
        if (this.inputListeners.has(element)) {
          return;
        }
        const listener = this.createTextAreaListener(element);
        this.inputListeners.set(element, listener);
        element.addEventListener("input", listener);
      } else if (element instanceof HTMLElement && element.contentEditable === "true") {
        if (this.contentEditableListeners.has(element)) {
          return;
        }
        const listener = this.createContentEditableListener(element);
        this.contentEditableListeners.set(element, listener);
        element.addEventListener("input", listener);
        element.addEventListener("keyup", listener);
      }
    }
    createTextAreaListener(element) {
      return async (event) => {
        const target = event.target;
        const value = target.value;
        const keywordMatch = value.match(/::\w+$/);
        if (keywordMatch) {
          const keyword = keywordMatch[0];
          try {
            const prompt = await this.promptManager.getPromptByKeyword(keyword);
            if (prompt) {
              const newValue = value.replace(keyword, prompt.content);
              target.value = newValue;
              target.dispatchEvent(new Event("input", { bubbles: true }));
              this.showFeedback(target, "Prompt inserted!");
            }
          } catch (error) {
            console.error("Error retrieving prompt:", error);
          }
        }
      };
    }
    createContentEditableListener(element) {
      return async (event) => {
        const target = event.target;
        const textContent = target.textContent || "";
        const keywordMatch = textContent.match(/::\w+$/);
        if (keywordMatch) {
          const keyword = keywordMatch[0];
          try {
            const prompt = await this.promptManager.getPromptByKeyword(keyword);
            if (prompt) {
              const selection = window.getSelection();
              if (selection && selection.rangeCount > 0) {
                const range = selection.getRangeAt(0);
                const walker = document.createTreeWalker(
                  target,
                  NodeFilter.SHOW_TEXT
                );
                let textNode = null;
                let node = null;
                while (node = walker.nextNode()) {
                  if (node.textContent && node.textContent.includes(keyword)) {
                    textNode = node;
                    break;
                  }
                }
                if (textNode) {
                  const startIndex = textNode.textContent.lastIndexOf(keyword);
                  const endIndex = startIndex + keyword.length;
                  const newRange = document.createRange();
                  newRange.setStart(textNode, startIndex);
                  newRange.setEnd(textNode, endIndex);
                  newRange.deleteContents();
                  newRange.insertNode(document.createTextNode(prompt.content));
                  selection.removeAllRanges();
                  const endRange = document.createRange();
                  endRange.setStartAfter(newRange.endContainer);
                  endRange.collapse(true);
                  selection.addRange(endRange);
                  this.showFeedback(target, "Prompt inserted!");
                }
              }
            }
          } catch (error) {
            console.error("Error retrieving prompt:", error);
          }
        }
      };
    }
    showFeedback(element, message) {
      const feedback = document.createElement("div");
      feedback.textContent = message;
      feedback.style.cssText = `
      position: absolute;
      background: #28a745;
      color: white;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      z-index: 10001;
      pointer-events: none;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;
      const rect = element.getBoundingClientRect();
      feedback.style.left = `${rect.left}px`;
      feedback.style.top = `${rect.top - 30}px`;
      document.body.appendChild(feedback);
      setTimeout(() => {
        if (feedback.parentNode) {
          feedback.parentNode.removeChild(feedback);
        }
      }, 2e3);
    }
    stopObserving() {
      if (this.observer) {
        this.observer.disconnect();
        this.observer = null;
      }
      this.inputListeners.forEach((listener, element) => {
        element.removeEventListener("input", listener);
      });
      this.inputListeners.clear();
      this.contentEditableListeners.forEach((listener, element) => {
        element.removeEventListener("input", listener);
        element.removeEventListener("keyup", listener);
      });
      this.contentEditableListeners.clear();
    }
    restartObserving() {
      this.stopObserving();
      this.startObserving();
    }
  };
})();
